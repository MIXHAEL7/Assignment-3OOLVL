#include "library.h"
#include <iostream>

int main()
{
    BookItem book1(" CPE 303", "MADUABUCHI_MISHAEL", "211203038");

    Patron patron1("DR. ALI", "15TH_JAN_2024");

    Library library;

    library.addBook(book1);

    library.addPatron(patron1);

    library.borrowBook(patron1, book1, "15th January 2024");

    library.borrowBook(patron1, book1, "20th January 2024");

    library.returnBook(patron1, book1);

    return 0;
}
