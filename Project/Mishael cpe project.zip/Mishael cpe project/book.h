#ifndef BOOK_H 
#define BOOK_H

#include <string>

class Book
{
private:
    std::string title;
    std::string author;
    std::string isbn;

public:
    // Constructor
    Book(const std::string& title, const std::string& author, const std::string& isbn)
        : title(title), author(author), isbn(isbn)
    {
    }

    // Setters
    void setTitle(const std::string& newTitle)
    {
        title = newTitle;
    }

    void setAuthor(const std::string& newAuthor)
    {
        author = newAuthor;
    }

    void setIsbn(const std::string& newIsbn)
    {
        isbn = newIsbn;
    }

    // Getters
    std::string getTitle() const
    {
        return title;
    }

    std::string getAuthor() const
    {
        return author;
    }

    std::string getIsbn() const
    {
        return isbn;
    }
};

#endif // BOOK_H
